Created tile images inside the Tiles folder at 64x64 pixels
Total tiles: 5 rows × 7 columns = 35 tiles
Tile names follow the pattern TileR[row number]C[column number], where R stands for row and C stands for column. TileR1C1.png is the top-left tile. Place them in order as needed.
Unwalkable tiles are labeled by adding _ground to the end of the tile name
Interaction tiles are labeled by adding _Interaction to the end of the tile name
Total unwalkable tiles: 7
Total interaction tiles: 0